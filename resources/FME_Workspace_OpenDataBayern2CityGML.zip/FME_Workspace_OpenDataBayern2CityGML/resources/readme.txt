The following codelists have been used for the Landuse Attribute values:
class: https://www.sig3d.org/codelists/citygml/2.0/landuse/2.0/LandUse_class.xml
usage: https://www.sig3d.org/codelists/citygml/2.0/landuse/2.0/LandUse_usage.xml